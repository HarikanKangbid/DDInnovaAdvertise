//
//  DDInnovaAdvertise.h
//  DDInnovaAdvertise
//
//  Created by Harikan Kangbid on 3/21/2560 BE.
//  Copyright © 2560 DDInnova. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DDInnovaAdvertise.
FOUNDATION_EXPORT double DDInnovaAdvertiseVersionNumber;

//! Project version string for DDInnovaAdvertise.
FOUNDATION_EXPORT const unsigned char DDInnovaAdvertiseVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DDInnovaAdvertise/PublicHeader.h>


